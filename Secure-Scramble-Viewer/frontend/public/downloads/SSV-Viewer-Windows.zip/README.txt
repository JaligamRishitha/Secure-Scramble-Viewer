SSV Viewer - Source Installation
================================

This package contains the Python source for SSV Viewer.
Use this if pre-built binaries are not available for your platform.

Requirements:
- Python 3.8 or higher
- tkinter (usually included with Python)

Installation:
-------------
Windows: Double-click install_windows.bat
macOS:   Run ./install_mac.sh in Terminal

Manual Installation:
-------------------
1. pip install -r requirements.txt
2. python ssv_viewer_enhanced.py <file.ssv>

Configuration:
--------------
Create ~/.ssv_decoder/config.txt with your secret key
(Get the key from your administrator)

