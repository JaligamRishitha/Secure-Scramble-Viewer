#!/bin/bash
echo "Installing SSV Viewer for macOS..."
echo

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "Python3 not found! Please install Python 3.8+"
    echo "brew install python3"
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt

# Create config directory
mkdir -p ~/.ssv_decoder

echo
echo "Installation complete!"
echo
echo "To run: python3 ssv_viewer_enhanced.py yourfile.ssv"
echo
echo "IMPORTANT: Create config file with your secret key:"
echo "echo 'YOUR_SECRET_KEY' > ~/.ssv_decoder/config.txt"
